<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'SKA' );

/** Database username */
define( 'DB_USER', 'SKA' );

/** Database password */
define( 'DB_PASSWORD', 'SKA' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'UanD3`xM5xde,)R,An{JB%l,MC]{49$O`me!<YM<T(L+PMh%ArPZrFV;;2T/,jUA' );
define( 'SECURE_AUTH_KEY',  '`RGlZLAA/Okl!tVXI+<o4a%NYk@ojeNLj+.8($wHxV;9UYzzb)`3T=Q,C GWptSD' );
define( 'LOGGED_IN_KEY',    'x+a*qVh>-iDFy)<&>HMjnb6EXplUl};zo~Vl(Bu6ig,#!UiQ=bj+!+?7M[5vQ@%s' );
define( 'NONCE_KEY',        'd+tVd>n}EQ(X0lV0I0`QTYZTvD6Lh5@3[CoWT;1Du8*bB<tTNKr87>#B?_s4=Y*C' );
define( 'AUTH_SALT',        ',9kBud6<~*j[U(?X&VV+><@UZ??;XJ8<g>|Xzg7<HX.]/1]jfp}(tPP.9d1R;-5N' );
define( 'SECURE_AUTH_SALT', 'd3h3GqN@-YRFzo5Qj lwR7ynoT8NX+3q|*IG(R97nT>uuSn+AwUSV(zJgUcI8+dQ' );
define( 'LOGGED_IN_SALT',   'fK2~190Dud2tOpBEO.U(^EVE?89 )hKS#$&3ENya51))nMWU&UjcuD}7!}ES&%g6' );
define( 'NONCE_SALT',       'AYgG3pVox7f_Tg!NC,S3BQm]sfO:1.rJN&OC7>ZWH>KgfrB^P6GFR?i8gj=N>),y' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
